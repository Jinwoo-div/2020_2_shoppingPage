package com.mybatis.sample.app;

public class imgBin {

}
